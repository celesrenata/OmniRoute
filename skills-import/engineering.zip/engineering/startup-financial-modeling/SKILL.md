---
name: startup-financial-modeling
description: Build comprehensive 3-5 year financial models with revenue projections, cost structures, cash flow analysis, and scenario planning for early-stage startups. Use this skill when creating financial projections, calculating burn rate or runway, modeling fundraising scenarios, or preparing investor-ready financials for a seed or Series A raise.
version: 1.0.0
---

# Startup Financial Modeling

Build comprehensive 3-5 year financial models with revenue projections, cost structures, cash flow analysis, and scenario planning for early-stage startups.

## Overview

Financial modeling provides the quantitative foundation for startup strategy, fundraising, and operational planning. Create realistic projections using cohort-based revenue modeling, detailed cost structures, and scenario analysis to support decision-making and investor presentations.

## Core Components

### Revenue Model

**Cohort-Based Projections:**
Build revenue from customer acquisition and retention by cohort.

**Formula:**

```
MRR = Σ (Cohort Size × Retention Rate × ARPU)
ARR = MRR × 12
```

**Key Inputs:**

- Monthly new customer acquisitions
- Customer retention rates by month
- Average revenue per user (ARPU)
- Pricing and packaging assumptions
- Expansion revenue (upsells, cross-sells)

### Cost Structure

**Operating Expenses Categories:**

1. **Cost of Goods Sold (COGS)**
   - Hosting and infrastructure
   - Payment processing fees
   - Customer support (variable portion)
   - Third-party services per customer

2. **Sales & Marketing (S&M)**
   - Customer acquisition cost (CAC)
   - Marketing programs and advertising
   - Sales team compensation
   - Marketing tools and software

3. **Research & Development (R&D)**
   - Engineering team compensation
   - Product management
   - Design and UX
   - Development tools and infrastructure

4. **General & Administrative (G&A)**
   - Executive team
   - Finance, legal, HR
   - Office and facilities
   - Insurance and compliance

### Cash Flow Analysis

**Components:**

- Beginning cash balance
- Cash inflows (revenue, fundraising)
- Cash outflows (operating expenses, CapEx)
- Ending cash balance
- Monthly burn rate
- Runway (months of cash remaining)

**Formula:**

```
Runway = Current Cash Balance / Monthly Burn Rate
Monthly Burn = Monthly Revenue - Monthly Expenses
```

### Headcount Planning

**Role-Based Hiring Plan:**
Track headcount by department and role.

**Key Metrics:**

- Fully-loaded cost per employee
- Revenue per employee
- Headcount by department (% of total)

**Typical Ratios (Early-Stage SaaS):**

- Engineering: 40-50%
- Sales & Marketing: 25-35%
- G&A: 10-15%
- Customer Success: 5-10%

## Financial Model Structure

### Three-Scenario Framework

**Conservative Scenario (P10):**

- Slower customer acquisition
- Lower pricing or conversion
- Higher churn rates
- Extended sales cycles
- Used for cash management

**Base Scenario (P50):**

- Most likely outcomes
- Realistic assumptions
- Primary planning scenario
- Used for board reporting

**Optimistic Scenario (P90):**

- Faster growth
- Better unit economics
- Lower churn
- Used for upside planning

### Time Horizon

**Detailed Projections: 3 Years**

- Monthly detail for Year 1
- Monthly detail for Year 2
- Quarterly detail for Year 3

**High-Level Projections: Years 4-5**

- Annual projections
- Key metrics only
- Support long-term planning

## Detailed section: Step-by-Step Process

Originally a 2763-byte section in this SKILL.md. Moved to `references/details.md` to fit Codex's 8 KB skill body cap.

## Business Model Templates

### SaaS Financial Model

**Revenue Drivers:**

- New MRR (customers × ARPU)
- Expansion MRR (upsells)
- Contraction MRR (downgrades)
- Churned MRR (lost customers)

**Key Ratios:**

- Gross margin: 75-85%
- S&M as % revenue: 40-60% (early stage)
- CAC payback: < 12 months
- Net retention: 100-120%

**Example Projection:**

```
Year 1: $500K ARR, 50 customers, $100K MRR by Dec
Year 2: $2.5M ARR, 200 customers, $208K MRR by Dec
Year 3: $8M ARR, 600 customers, $667K MRR by Dec
```

### Marketplace Financial Model

**Revenue Drivers:**

- GMV (Gross Merchandise Value)
- Take rate (% of GMV)
- Net revenue = GMV × Take rate

**Key Ratios:**

- Take rate: 10-30% depending on category
- CAC for buyers vs. sellers
- Contribution margin: 60-70%

**Example Projection:**

```
Year 1: $5M GMV, 15% take rate = $750K revenue
Year 2: $20M GMV, 15% take rate = $3M revenue
Year 3: $60M GMV, 15% take rate = $9M revenue
```

### E-Commerce Financial Model

**Revenue Drivers:**

- Traffic (visitors)
- Conversion rate
- Average order value (AOV)
- Purchase frequency

**Key Ratios:**

- Gross margin: 40-60%
- Contribution margin: 20-35%
- CAC payback: 3-6 months

### Services / Agency Financial Model

**Revenue Drivers:**

- Billable hours or projects
- Hourly rate or project fee
- Utilization rate
- Team capacity

**Key Ratios:**

- Gross margin: 50-70%
- Utilization: 70-85%
- Revenue per employee

## Fundraising Integration

### Funding Scenario Modeling

**Pre-Money Valuation:**
Based on metrics and comparables.

**Dilution:**

```
Post-Money = Pre-Money + Investment
Dilution % = Investment / Post-Money
```

**Use of Funds:**
Allocate funding to extend runway and achieve milestones.

**Example:**

```
Raise: $5M at $20M pre-money
Post-Money: $25M
Dilution: 20%

Use of Funds:
- Product Development: $2M (40%)
- Sales & Marketing: $2M (40%)
- G&A and Operations: $0.5M (10%)
- Working Capital: $0.5M (10%)
```

### Milestone-Based Planning

**Identify Key Milestones:**

- Product launch
- First $1M ARR
- Break-even on CAC
- Series A fundraise

**Funding Amount:**
Ensure runway to achieve next milestone + 6 months buffer.

## Common Pitfalls

**Pitfall 1: Overly Optimistic Revenue**

- New startups rarely hit aggressive projections
- Use conservative customer acquisition assumptions
- Model realistic churn rates

**Pitfall 2: Underestimating Costs**

- Add 20% buffer to expense estimates
- Include fully-loaded compensation
- Account for software and tools

**Pitfall 3: Ignoring Cash Flow Timing**

- Revenue ≠ cash (payment terms)
- Expenses paid before revenue collected
- Model cash conversion carefully

**Pitfall 4: Static Headcount**

- Hiring takes time (3-6 months to fill roles)
- Ramp time for productivity (3-6 months)
- Account for attrition (10-15% annually)

**Pitfall 5: Not Scenario Planning**

- Single scenario is never accurate
- Always model conservative case
- Plan for what you'll do if base case fails

## Model Validation

**Sanity Checks:**

- [ ] Revenue growth rate is achievable (3x in Year 2, 2x in Year 3)
- [ ] Unit economics are realistic (LTV/CAC > 3, payback < 18 months)
- [ ] Burn multiple is reasonable (< 2.0 in Year 2-3)
- [ ] Headcount scales with revenue (revenue per employee growing)
- [ ] Gross margin is appropriate for business model
- [ ] S&M spending aligns with CAC and growth targets

**Benchmark Against Peers:**
Compare key metrics to similar companies at similar stage.

**Investor Feedback:**
Share model with advisors or investors for feedback on assumptions.


## Quick Start

To create a startup financial model:

1. **Define business model** - Revenue drivers and pricing
2. **Project revenue** - Cohort-based with retention
3. **Model costs** - COGS, S&M, R&D, G&A by month
4. **Plan headcount** - Hiring by role and department
5. **Calculate cash flow** - Revenue - expenses = burn/runway
6. **Compute metrics** - CAC, LTV, burn multiple, runway
7. **Create scenarios** - Conservative, base, optimistic
8. **Validate assumptions** - Sanity check and benchmark
9. **Integrate fundraising** - Model funding rounds and milestones
