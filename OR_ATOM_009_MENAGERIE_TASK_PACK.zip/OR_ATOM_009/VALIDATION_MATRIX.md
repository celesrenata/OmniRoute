# OR-ATOM-009 Visual + Telemetry Validation Matrix

Use real/browser captures. For simulated data, mark **DEMO** conspicuously. For disconnected metrics, mark **UNAVAILABLE**.

| Scenario | Proven device/runtime | TPS value + source + age | Queue + source + age | Lane + source | Model(s) + source | Nucleus speed | Cloud hue | Discharge result | Capture | Result |
|---|---|---|---|---|---|---|---|---|---|---|
| Idle (measured zero) | | | | | | | | | | |
| Unknown/stale | | | | | | | | | | |
| 20 TPS | | | | | | | | | | |
| 80 TPS | | | | | | | | | | |
| Queued jobs | | | | | | | | | | |
| 2 mixed lanes | | | | | | | | | | |
| Completion | | | | | | | | | | |
| Failed request | | | | | | | | | | |
| Multi-runtime GPU | | | | | | | | | | |

## Stability

| Test | Duration | FPS p50/p95 | Draw calls | Geometry count start/end | Texture count start/end | WebGL lost contexts | Browser console errors | Result |
|---|---|---|---|---|---|---|---|---|
| Live telemetry soak | 20 min | | | | | | | |
| 2D↔Atomic repeated toggle | | | | | | | | |
| Context loss + restore | | | | | | | | |

Always label unperformed tests as **NOT RUN**; build success is not browser validation.
