Implement **OR-ATOM-007 — Skill-Hub-Powered Atomic Visual Fidelity Overhaul** using the attached `CONTEXT.md` in the CURRENT local OmniRoute worktree.

We are still far from the original cinematic atom concept. Before changing scene code, **connect to our live OmniRoute Skill Hub MCP and discover the relevant skills among the approximately 910 installed skills**. Use `omr_skill_list` for the live total/domains, `omr_skill_search` across WebGL/R3F/Three.js/GLSL/shaders/bloom/volumetric particles/electric arcs/performance/browser visual testing, then `omr_skill_get` to load the complete selected SKILL.md instructions. Use `omr_catalog_resource` for referenced support files when helpful. Newly imported skills may require one authorized catalog refresh. Record exact IDs/revisions, rank their relevance, and map each loaded skill to concrete source files and implementation decisions.

**Do not merely mention or list skills: apply their techniques.** Provide selected full skill content to isolated implementation workers and record evidence of application. Imported skills are commonly instruction-only, not executable MCP programs.

First make sure the previous two-minute blank-WebGL-canvas regression is actually fixed (the original release code creates a fresh WebGL2 context in its React render path). Then substantially improve the atom materials/colored nuclei, truly luminous layered electron clouds, subtle idle energy links, and active/completion/failure electrical discharges. Preserve truthful TPS, queue, lane, and model mappings.

**HARD FREEZE:** Do not modify camera, zoom, layout, node positioning, labels, collision handling, Pause/Reset controls, navigation, or the ReactFlow fallback. The previous close-up screenshots were intentionally zoomed.

Use parallel read-only discovery, then parallel isolated code workers. Keep the renderer a lazy-loaded optional plugin. Do not change live fleet infrastructure, credentials, or deployments. Implement, run a real browser, compare against the original concept, capture screenshots across idle/active/error and normal/zoomed views, and run a 15–30 minute soak to verify WebGL remains visible.

Do not stop after planning or skill discovery. Deliver improved running code, `SKILL_AUDIT.md`, `SKILL_APPLICATION_REPORT.md`, tests/build output, before/after screenshots, and benchmark results. If live MCP access is genuinely blocked, report the exact blocker and complete the safe independent portions, but do not claim to have inspected skills you could not load.
